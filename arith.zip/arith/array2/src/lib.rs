pub struct Array2<T> {
    pub width: usize,
    pub height: usize,
    pub data: Vec<Vec<T>>,
}

impl<T: Clone> Array2<T> {
    pub fn blank_filled(width: usize, height: usize, default_val: T) -> Self {
        Array2 {
            width,
            height,
            data: vec![vec![default_val; width]; height],
        }
    }

    pub fn from_row_major(width: usize, height: usize, values: Vec<T>) -> Self {
        let rows = values
            .chunks(width)
            .take(height)
            .map(|chunk| chunk.to_vec())
            .collect();

        Array2 {
            width,
            height,
            data: rows,
        }
    }

    pub fn get(&self, y: usize, x: usize) -> Option<&T> {
        if y < self.height && x < self.width {
            Some(&self.data[y][x])
        } else {
            None
        }
    }

    pub fn get_mut(&mut self, row: usize, col: usize) -> Option<&mut T> {
        if row < self.height && col < self.width {
            Some(&mut self.data[row][col])
        } else {
            None
        }
    }

    pub fn change_element(&mut self, row: usize, col: usize, new_value: T) -> Option<()> {
        if row < self.height && col < self.width {
            self.data[row][col] = new_value;
            Some(())
        } else {
            None
        }
    }

    pub fn iter_row_major(&self) -> impl Iterator<Item = &T> {
        self.data.iter().flatten()
    }

    pub fn trim(&self, new_width: usize, new_height: usize) -> Array2<T> {
        let trimmed_data: Vec<Vec<T>> = self
            .data
            .iter()
            .take(new_height)
            .map(|row| row.iter().take(new_width).cloned().collect())
            .collect();

        Array2 {
            width: new_width,
            height: new_height,
            data: trimmed_data,
        }
    }
}
