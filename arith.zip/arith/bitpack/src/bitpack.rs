/// Returns true iff the signed value `n` fits into `width` signed bits.
///
/// # Arguments:
/// * `n`: A signed integer value
/// * `width`: the width of a bit field
pub fn fitss(n: i64, width: u64) -> bool {
    if width == 0 {
        return n == 0;
    }
    if width >= 64 {
        return true;
    }
    let shift_am: u64 = 64 - width;
    let shift_left = n << shift_am;
    let shift_right = shift_left >> shift_am;
    shift_right == n
}

/// Returns true iff the unsigned value `n` fits into `width` unsigned bits.
///
/// # Arguments:
/// * `n`: An unsigned integer value
/// * `width`: the width of a bit field
pub fn fitsu(n: u64, width: u64) -> bool {
    if width >= 64 {
        return true;
    }
    (n >> width) == 0
}

/// Retrieve a signed value from `word`, represented by `width` bits
/// beginning at least-significant bit `lsb`.
/// Returns `None` if `width+lsb > 64`
///
/// # Arguments:
/// * `word`: An unsigned word
/// * `width`: the width of a bit field
/// * `lsb`: the least-significant bit of the bit field
pub fn gets(word: u64, width: u64, lsb: u64) -> Option<i64> {
    if width + lsb > 64 {
        return None;
    }
    if width == 0 {
        return Some(0);
    }
    let shift_b = word >> lsb;
    let up = 64 - width;
    let sign_extended = ((shift_b as i64) << up) >> up;
    Some(sign_extended)
}

/// Retrieve an unsigned value from `word`, represented by `width` bits
/// beginning at least-significant bit `lsb`.
/// Returns `None` if `width+lsb > 64`
///
/// # Arguments:
/// * `word`: An unsigned word
/// * `width`: the width of a bit field
/// * `lsb`: the least-significant bit of the bit field
pub fn getu(word: u64, width: u64, lsb: u64) -> Option<u64> {
    if width + lsb > 64 {
        return None;
    }
    if width == 0 {
        return Some(0);
    }
    let left_shift_amt = 64 - (width + lsb);
    let left_cleared = word << left_shift_amt;
    let right_shift_amt = 64 - width;
    let result = left_cleared >> right_shift_amt;
    Some(result)
}

/// Return a modified version of the unsigned `word`,
/// which has been updated so that the `width` bits beginning at
/// least-significant bit `lsb` now contain the unsigned `value`.
/// Returns an `Option` which will be None iff the value does not fit
/// in `width` unsigned bits.
///
/// # Arguments:
/// * `word`: An unsigned word
/// * `width`: the width of a bit field
/// * `lsb`: the least-significant bit of the bit field
/// * `value`: the unsigned value to place into that bit field
pub fn newu(word: u64, width: u64, lsb: u64, value: u64) -> Option<u64> {
    if width + lsb > 64 {
        return None;
    }
    if !fitsu(value, width) {
        return None;
    }
    if width == 0 {
        return Some(word);
    }
    let mut all_ones: u64 = !0;
    if width < 64 {
        all_ones = !0u64 >> (64 - width);
    }
    let mask_at_pos = all_ones << lsb;
    let hole_puncher = !mask_at_pos;
    let word_with_hole = word & hole_puncher;
    let aligned_value = value << lsb;
    Some(word_with_hole | aligned_value)
}

/// Return a modified version of the unsigned `word`,
/// which has been updated so that the `width` bits beginning at
/// least-significant bit `lsb` now contain the signed `value`.
/// Returns an `Option` which will be None iff the value does not fit
/// in `width` signed bits.
///
/// # Arguments:
/// * `word`: An unsigned word
/// * `width`: the width of a bit field
/// * `lsb`: the least-significant bit of the bit field
/// * `value`: the signed value to place into that bit field
pub fn news(word: u64, width: u64, lsb: u64, value: i64) -> Option<u64> {
    if lsb + width > 64 {
        return None;
    }
    if !fitss(value, width) {
        return None;
    }
    if width == 0 {
        return Some(word);
    }
    let mut mask: u64 = !0;
    if width < 64 {
        mask = !0u64 >> (64 - width);
    }
    let mask_at_pos = mask << lsb;
    let hole_puncher = !mask_at_pos;
    let word_with_hole = word & hole_puncher;
    let aligned_value = (value as u64 & mask) << lsb;
    Some(word_with_hole | aligned_value)
}
