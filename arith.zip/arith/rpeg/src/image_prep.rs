use crate::video_struct::Video;
use array2::Array2;
use csc411_image;
use csc411_image::{Rgb, RgbImage};

/// Prepares a raw RgbImage for compression by converting it into an Array2 of
/// Video pixels in YPbPr color space, trimming any odd-dimensioned edges.
///
/// Performs the following steps:
/// 1. Lays out the raw pixels into a row-major Array2.
/// 2. Trims the image to even dimensions by removing any odd trailing row or column.
/// 3. Converts each pixel from RGB to floating point YPbPr color space.
///
/// # Arguments
/// * `img` - The source RgbImage containing raw pixel data, dimensions, and denominator.
///
/// # Returns
/// `Some(Array2<Video>)` with even dimensions in YPbPr color space, or `None` if
/// trimming or conversion fails.
pub fn prep_image(img: RgbImage) -> Option<Array2<Video>> {
    let dem = img.denominator;
    let array2filled = Array2::from_row_major(img.width as usize, img.height as usize, img.pixels);
    let trimmed = trim_image(array2filled, img.width as usize, img.height as usize)?;

    floating(trimmed, dem as f64)
}

fn trim_image(arr: Array2<Rgb>, width: usize, height: usize) -> Option<Array2<Rgb>> {
    if (width % 2) != 0 && (height % 2) == 0 {
        return Some(arr.trim(width - 1, height));
    } else if (height % 2) != 0 && (width % 2) == 0 {
        return Some(arr.trim(width, height - 1));
    } else if (width % 2) != 0 && (height % 2) != 0 {
        return Some(arr.trim(width - 1, height - 1));
    }
    Some(arr)
}

fn floating(arr: Array2<Rgb>, denom: f64) -> Option<Array2<Video>> {
    let mut out = Array2::blank_filled(
        arr.width,
        arr.height,
        Video {
            y: 0.0,
            pb: 0.0,
            pr: 0.0,
        },
    );

    for r in 0..arr.height {
        for c in 0..arr.width {
            let pixel = arr.get(r, c).unwrap();
            let float_pixel = Video {
                y: pixel.red as f32 / denom as f32,
                pb: pixel.green as f32 / denom as f32,
                pr: pixel.blue as f32 / denom as f32,
            };
            out.change_element(r, c, float_pixel);
        }
    }
    Some(out)
}
