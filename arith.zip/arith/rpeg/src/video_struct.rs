#[derive(Clone, Debug)]
pub struct Video {
    pub y: f32,
    pub pb: f32,
    pub pr: f32,
}

#[derive(Clone, Debug)]
pub struct PackedWordStruct {
    pub pb: usize,
    pub pr: usize,
    pub a: i32,
    pub b: i32,
    pub c: i32,
    pub d: i32,
}
