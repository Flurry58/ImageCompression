use crate::video_struct::Video;
use array2::Array2;
use csc411_image::Rgb;

/// Converts an Array2 of pixels from RGB color space to YPbPr video color space
/// in place, overwriting each pixel with its converted values.
///
/// Each pixel's RGB components are stored in the Video struct fields as
/// y=R, pb=G, pr=B, and are converted using the standard RGB to YPbPr
/// transformation matrix.
///
/// # Arguments
/// * `arr` - An Array2 of Video structs containing RGB pixel data.
///
/// # Returns
/// `Some(Array2<Video>)` containing the converted pixels in YPbPr color space.
pub fn to_video(mut arr: Array2<Video>) -> Option<Array2<Video>> {
    for y in 0..arr.height {
        for x in 0..arr.width {
            arr.get(y, x).expect("Bounds check failed!"); // Error Checking (For testing only)

            let ytemp = 0.299 * arr.get(y, x).unwrap().y
                + 0.587 * arr.get(y, x).unwrap().pb
                + 0.114 * arr.get(y, x).unwrap().pr;
            let pb_n = -0.168736 * arr.get(y, x).unwrap().y - 0.331264 * arr.get(y, x).unwrap().pb
                + 0.5 * arr.get(y, x).unwrap().pr;
            let pr_n = 0.5 * arr.get(y, x).unwrap().y
                - 0.418688 * arr.get(y, x).unwrap().pb
                - 0.081312 * arr.get(y, x).unwrap().pr;
            let new_video = Video {
                y: ytemp,
                pb: pb_n,
                pr: pr_n,
            };

            arr.change_element(y, x, new_video);
        }
    }
    Some(arr)
}

/// Converts an Array2 of Video pixels from YPbPr color space to RGB color space
/// using the standard YPbPr to RGB transformation matrix.
///
/// Each resulting RGB component is scaled by `denom` and clamped to the range
/// [0, denom] before being stored as a u16.
///
/// # Arguments
/// * `arr` - An Array2 of Video structs containing pixels in YPbPr color space.
/// * `denom` - The denominator (maximum value) used to scale the RGB output,
///             typically the denominator from the source image (e.g. 255).
///
/// # Returns
/// `Some(Array2<Rgb>)` containing the converted pixels in RGB color space.
pub fn to_rgb(arr: Array2<Video>, denom: u16) -> Option<Array2<Rgb>> {
    let mut output = Array2::blank_filled(
        arr.width,
        arr.height,
        Rgb {
            red: 0,
            green: 0,
            blue: 0,
        },
    );

    for r in 0..arr.height {
        for c in 0..arr.width {
            let pixel = arr.get(r, c).expect("Coordinate out of bounds");

            let r_val = 1.0 * pixel.y + 0.0 * pixel.pb + 1.402 * pixel.pr;
            let g_val = 1.0 * pixel.y - 0.344136 * pixel.pb - 0.714136 * pixel.pr;
            let b_val = 1.0 * pixel.y + 1.772 * pixel.pb + 0.0 * pixel.pr;

            let new_rgb = Rgb {
                red: (r_val * denom as f32).clamp(0.0, denom as f32) as u16,
                green: (g_val * denom as f32).clamp(0.0, denom as f32) as u16,
                blue: (b_val * denom as f32).clamp(0.0, denom as f32) as u16,
            };

            output.change_element(r, c, new_rgb);
        }
    }

    Some(output)
}
