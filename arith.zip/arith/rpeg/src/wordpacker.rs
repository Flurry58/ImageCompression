use crate::video_struct::{PackedWordStruct, Video};
use array2::Array2;
use bitpack;
use csc411_arith;

static COSINE_FORCE: f32 = 0.3;

//Only for testing
pub fn bit_wordpacker_test(arr: Array2<PackedWordStruct>) -> Array2<PackedWordStruct> {
    let mut compressed_data: Vec<[u8; 4]> = Vec::new();
    for r in 0..arr.height {
        for c in 0..arr.width {
            let cell = arr.get(r, c).unwrap();
            let word = pack_to_u64(cell);
            compressed_data.push((word as u32).to_be_bytes());
        }
    }
    let out1 = bit_unpacker(compressed_data, arr.width * 2, arr.height * 2);
    out1
}

/// Packs a word struct into code words then write it to standard out
///
/// # Arguments
///  * 'arr': Array2 of PackWordStruct, recieved from the packer function
pub fn bit_wordpacker(arr: Array2<PackedWordStruct>) {
    let width = arr.width * 2;
    let height = arr.height * 2;

    let mut compressed_data: Vec<[u8; 4]> = Vec::new();
    for r in 0..arr.height {
        for c in 0..arr.width {
            let cell = arr.get(r, c).unwrap();
            let word = pack_to_u64(cell);
            compressed_data.push((word as u32).to_be_bytes());
        }
    }

    csc411_rpegio::output_rpeg_data(&compressed_data, width, height).unwrap();
}

/// Unpackes a given array of word bytes
///
/// # Arguments
///  * `compressed_data`: Vector of binary words
///  * `width` : width from binary file header
///  * `height`: height from binary file header
pub fn bit_unpacker(
    compressed_data: Vec<[u8; 4]>,
    width: usize,
    height: usize,
) -> Array2<PackedWordStruct> {
    let mut output = Array2::blank_filled(
        width / 2,
        height / 2,
        PackedWordStruct {
            pb: 0,
            pr: 0,
            a: 0,
            b: 0,
            c: 0,
            d: 0,
        },
    );

    let mut i = 0;
    for r in 0..output.height {
        for c in 0..output.width {
            let word = u32::from_be_bytes(compressed_data[i]) as u64;
            output.change_element(r, c, unpack_from_u64(word));
            i += 1;
        }
    }

    output
}

fn pack_to_u64(cell: &PackedWordStruct) -> u64 {
    let mut word: u64 = 0;
    word = bitpack::newu(word, 4, 0, cell.pr as u64).unwrap();
    word = bitpack::newu(word, 4, 4, cell.pb as u64).unwrap();
    word = bitpack::news(word, 5, 8, cell.d as i64).unwrap();
    word = bitpack::news(word, 5, 13, cell.c as i64).unwrap();
    word = bitpack::news(word, 5, 18, cell.b as i64).unwrap();
    word = bitpack::newu(word, 9, 23, cell.a as u64).unwrap();
    word
}

fn unpack_from_u64(word: u64) -> PackedWordStruct {
    PackedWordStruct {
        pr: bitpack::getu(word, 4, 0).unwrap() as usize,
        pb: bitpack::getu(word, 4, 4).unwrap() as usize,
        d: bitpack::gets(word, 5, 8).unwrap() as i32,
        c: bitpack::gets(word, 5, 13).unwrap() as i32,
        b: bitpack::gets(word, 5, 18).unwrap() as i32,
        a: bitpack::getu(word, 9, 23).unwrap() as i32,
    }
}

pub fn packer(arr: Array2<Video>) -> Array2<PackedWordStruct> {
    let mut output = Array2::blank_filled(
        arr.width / 2,
        arr.height / 2,
        PackedWordStruct {
            pb: 0,
            pr: 0,
            a: 0,
            b: 0,
            c: 0,
            d: 0,
        },
    );

    for r in (0..arr.height).step_by(2) {
        for c in (0..arr.width).step_by(2) {
            let i1 = arr.get(r, c).unwrap();
            let i2 = arr.get(r, c + 1).unwrap();
            let i3 = arr.get(r + 1, c).unwrap();
            let i4 = arr.get(r + 1, c + 1).unwrap();

            let pr_average: f32 = (i1.pr + i2.pr + i3.pr + i4.pr) / 4.0;
            let pb_average: f32 = (i1.pb + i2.pb + i3.pb + i4.pb) / 4.0;
            let pb_index = csc411_arith::index_of_chroma(pb_average);
            let pr_index = csc411_arith::index_of_chroma(pr_average);

            let a_raw = (i1.y + i2.y + i3.y + i4.y) / 4.0;
            let b_raw = (i4.y + i3.y - i2.y - i1.y) / 4.0;
            let c_raw = (i4.y - i3.y + i2.y - i1.y) / 4.0;
            let d_raw = (i4.y - i3.y - i2.y + i1.y) / 4.0;

            let a_encode = encode_a(a_raw);
            let b_encode = encode_bcd(b_raw);
            let c_encode = encode_bcd(c_raw);
            let d_encode = encode_bcd(d_raw);

            let output_insert = PackedWordStruct {
                pb: pb_index,
                pr: pr_index,
                a: a_encode,
                b: b_encode,
                c: c_encode,
                d: d_encode,
            };

            output.change_element(r / 2, c / 2, output_insert);
        }
    }
    output
}

/// Converts an Array2 of PackedWordStructs into an Array2 of Video pixels
/// by reversing the discrete cosine transform (DCT) and chroma subsampling.
///
/// For each packed word, the average chroma values (Pb, Pr) are restored via
/// lookup table, and the four luminance values (Y) are recovered by inverting
/// the DCT coefficients (a, b, c, d) across the corresponding 2x2 pixel block.
///
/// # Arguments
/// * `arr` - An Array2 of PackedWordStructs, where each cell represents a 2x2
///           block of pixels encoded with DCT coefficients and chroma indices.
///
/// # Returns
/// An Array2 of Video pixels with dimensions twice the width and height of the
/// input, where each pixel contains Y, Pb, and Pr values in video color space.
pub fn unpacker(arr: Array2<PackedWordStruct>) -> Array2<Video> {
    let mut output = Array2::blank_filled(
        arr.width * 2,
        arr.height * 2,
        Video {
            y: 0.0,
            pb: 0.0,
            pr: 0.0,
        },
    );
    for r in 0..arr.height {
        for c in 0..arr.width {
            let cell = arr.get(r, c).unwrap();
            let pr_average = csc411_arith::chroma_of_index(cell.pr);
            let pb_average = csc411_arith::chroma_of_index(cell.pb);

            let a = decode_a(cell.a);
            let b = decode_bcd(cell.b);
            let c_val = decode_bcd(cell.c);
            let d = decode_bcd(cell.d);

            let y1 = a - b - c_val + d;
            let y2 = a - b + c_val - d;
            let y3 = a + b - c_val - d;
            let y4 = a + b + c_val + d;

            output.change_element(
                r * 2,
                c * 2,
                Video {
                    y: y1,
                    pb: pb_average,
                    pr: pr_average,
                },
            );
            output.change_element(
                r * 2,
                c * 2 + 1,
                Video {
                    y: y2,
                    pb: pb_average,
                    pr: pr_average,
                },
            );
            output.change_element(
                r * 2 + 1,
                c * 2,
                Video {
                    y: y3,
                    pb: pb_average,
                    pr: pr_average,
                },
            );
            output.change_element(
                r * 2 + 1,
                c * 2 + 1,
                Video {
                    y: y4,
                    pb: pb_average,
                    pr: pr_average,
                },
            );
        }
    }
    output
}

// --------------Quantization--------------

fn scale_sat(x: f32, max_magnitude: f32) -> f32 {
    if x > max_magnitude {
        max_magnitude
    } else if x < -max_magnitude {
        -max_magnitude
    } else {
        x
    }
}

fn smax(bits: i32) -> i32 {
    ((1 << bits) / 2) - 1
}

fn encode_a(a: f32) -> i32 {
    (a * smax(9) as f32).floor() as i32
}

fn encode_bcd(x: f32) -> i32 {
    let b_bits = 5;
    (scale_sat(x, COSINE_FORCE) * smax(b_bits) as f32).floor() as i32
}

fn decode_a(a: i32) -> f32 {
    a as f32 / smax(9) as f32
}

fn decode_bcd(x: i32) -> f32 {
    let b_bits = 5;
    x as f32 / smax(b_bits) as f32
}
