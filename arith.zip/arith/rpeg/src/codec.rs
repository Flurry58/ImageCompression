use crate::image_prep::prep_image;
use crate::video_struct::Video;
use crate::videocolor::{to_rgb, to_video};
use crate::wordpacker::{bit_unpacker, bit_wordpacker, packer, unpacker};
use array2::Array2;
use csc411_image::{Read, Rgb, RgbImage, Write};

pub fn compress(filename: Option<&str>) {
    let img;
    img = RgbImage::read(filename).unwrap();

    let prepped: Array2<Video> = prep_image(img).unwrap(); //Stores RGB values in video struct, still rgb

    // Hasn't been converted yet. Just so we can store floats effectivly
    let converted = to_video(prepped);
    let test = packer(converted.unwrap());

    bit_wordpacker(test);
    // --- Testing ---
    // let out1 = unpacker(out);
    // let back_rgb = to_rgb(out1, dem).unwrap();

    // let pixels: Vec<Rgb> = back_rgb.iter_row_major().cloned().collect();
    // let output = RgbImage {
    //     pixels: pixels,
    //     width: width as u32,
    //     height: height as u32,
    //     denominator: dem,
    // };
    // //println!("{:?}", output.pixels);

    // output
    //     .write(Some("pedeen.ppm"))
    //     .expect("Compression Failed to Write"); // Write to file if provided, stdout if None
}

pub fn decompress(filename: Option<&str>) {
    let dem = 255;
    let (compressed_data, width, height) = csc411_rpegio::input_rpeg_data(filename).unwrap();

    let out1 = bit_unpacker(compressed_data, width, height);
    let out = unpacker(out1);
    let back_rgb = to_rgb(out, dem).unwrap();

    let pixels: Vec<Rgb> = back_rgb.iter_row_major().cloned().collect();
    let output = RgbImage {
        pixels: pixels,
        width: width as u32,
        height: height as u32,
        denominator: dem,
    };

    output.write(filename).expect("Compression Failed to Write"); // Write to file if provided, stdout if None
}
